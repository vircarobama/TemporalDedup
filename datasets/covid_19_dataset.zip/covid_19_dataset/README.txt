---
Data source:

COVID-19 Open Data (https://research.google/tools/datasets/covid-19-open-data/).  "The repository contains datasets of daily time-series data related to COVID-19 for countries around the world.  The data is at the spatial resolution of states/provinces for most regions ... All regions are assigned a unique location key ..."  The dataset provided here combines information from the emergency-declarations and government-response data tables for U.S. states and territories only.

---
Files included:

* source_data directory
Provides URL links to the COVID-19 Open Data and the specific tables used to construct this dataset, namely emergency-declarations, government-response, and index.  The raw data pulled on February 2, 2022 that was directly used to construct this dataset is also provided for reference.

* covid_19_dataset_supplemented.txt
COVID-19 dataset used to apply the TemporalDedup algorithm and comparison method.  Tab delimited file with a header row with titles for each of the data columns.  The data was constructed by using COVID-19 Open Data for emergency declarations and government responses from each of the U.S. states and territories (see source_data directory).  Each data record details the dates when a particular U.S. state or territory first activated, last activated, first deactivated, or last deactivated each of the government responses or emergency declarations.  The dataset was supplemented with a small set of synthetic records (see synthetic_records.txt).

* covid_19_dataset_supplemented_with_rowids.txt
Adds left-most (first) column to note the unique identifier (ID) for each record.  Otherwise, the same as covid_19_dataset_supplemented.txt.  These IDs are used in the truth data and are useful for analysis.

* covid_19_truth_data.txt
Tab delimited file with a header row.  There are three columns: ID, Duplicate IDs, and Duplicate Classes.  Each row represents a single record that is a duplicate of at least one other record in the dataset.  For each duplicate record, the IDs of its duplicates and the corresponding duplicate class(es) are noted.  

* reported_attributes_by_index.txt
The recurring instances of the 'reported_attribute' attribute for each record in the dataset occur in a specific order.  Indexed from 0 on the first reported_attribute (lawatlas_mitigation_policy) to 115 on the last reported_attribute (vaccination_policy), this file provides for a quick reference.

* synthetic_records.txt
Identifies and describes all synthetic records that appear in the dataset.  For each, it is identified by its row ID, the ID of the real record used as the basis for duplication, a brief description on how the basis record was duplicated, and an enumeration of all attribute value differences.

---
Important notes regarding covid_19_truth_data.txt formatting: 
* Multiple IDs in 'Duplicate IDs' column are separated by a space
* If there is only one duplicate class listed, it applies to all duplicate IDs for that row
* Duplicate classes joined by ' & ' means that both are applicable
* If 'Duplicate Classes' contains commas, then the duplicate classes differ between the 'Duplicate IDs' and are listed in the respective order.
* For 'Duplicate Classes' values:
   EXACT corresponds to Exact match
   NONKEY corresponds to Key value differs
   TIMELINE corresponds to Timeline match
   ORDER corresponds to Unconstrained order match
   ELAPSED_TIME corresponds to Elapsed time match
   MODIFIED corresponds to Modified attributes

Duplicate classes are explained in detail in Section 4.2 of "TemporalDedup: Domain-Independent Deduplication of Redundant and Errant Temporal Data"

---
Additional notes:

* Each data record details the dates when a particular U.S. state or territory first activated, last activated, first deactivated, or last deactivated each of the government responses or emergency declarations.
* The attributes include the location key, country name, subregion name (i.e. state or territory name), data source, summary type (i.e. first activated, last activated, first deactivated, last deactivated), and a series of attributes – repeated for each government response or emergency declaration attribute – including the attribute name and the date that aligns with the summary type.
* The primary key of each record is location_key, summary_type.
* The files are tab delimited.
* The first row in each provided data file is a header row with titles for each of the columns.
